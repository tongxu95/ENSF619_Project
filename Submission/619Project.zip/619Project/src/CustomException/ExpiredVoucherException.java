package CustomException;

public class ExpiredVoucherException extends Exception {

}
