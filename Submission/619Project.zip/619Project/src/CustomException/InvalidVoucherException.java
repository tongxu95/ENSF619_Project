package CustomException;

public class InvalidVoucherException extends Exception {

}
