package CustomException;

public class InvalidPasswordException extends Exception {

}
