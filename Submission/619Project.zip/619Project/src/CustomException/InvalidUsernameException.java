package CustomException;

public class InvalidUsernameException extends Exception {

}
