package CustomException;


public class InvalidBankException extends Exception {

}
