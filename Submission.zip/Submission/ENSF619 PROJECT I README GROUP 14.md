ENSF 619 Project I Group 14 

John Van Heurn
(Jenny) Tong Xu
Javier Vite
Haixia Wu

README GUIDELINES 

To run the Booking model Java application, first run the SQL scripts (bookingModel.sql and create-user-objects.sql) to populate an SQL database. 

You may run the application from the App.java class. Before running the app, update the username and password in the MovieDBController.java and UserBankDBController.javas files to have correct inputs on the local machine.